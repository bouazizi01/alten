# ALTEN SHOP FRONT

Launch the front-end with `ng serve` or `npm start`.